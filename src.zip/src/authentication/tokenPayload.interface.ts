interface TokenPayload {
  userId: number;
}

export default TokenPayload;