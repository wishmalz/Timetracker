export class RegisterDto {
  email: string;
  name: string;
  password: string;
}

export default RegisterDto;